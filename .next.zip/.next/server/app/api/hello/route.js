var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/hello/route.js")
R.c("server/chunks/node_modules_next_dist_c6558f61._.js")
R.c("server/chunks/[root-of-the-server]__bcb07744._.js")
R.m("[project]/.next-internal/server/app/api/hello/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/hello/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/hello/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
